# Student Record Comparison
Application to Compare Students based on their names and ids.

## Description
A program to Compare students based on their Names and Ids, using compareTo() method where first comparison is on basis on Names. Considering the case where name of the two students are same this, program will run the check for the IDs number of the students and provide result of comparison after evaluating the case.


## ATTRIBUTES AND METHODS:
1) getName(); it returns the name of the Student to the name variable.
2) SetName(String name); it sets the name of the Student String
3) getId(); it returns the Student IDs.
4) SetId(int id); it Sets the Id of the Student Ids, which will be stored in the integer

5) comapareStudent(Student s1, Student s2):
- Primary Comparison: it Compares two students initially and it done by alphabetical order (Going through Unicode of each character)
- Secondary Comparison: if the student names are same and their ids will be compare using the same method (Going through Unicode of Each Number)

## MAIN PROCESS
1) The User will ask for the Student Details; it will ask Names and ids. Total test cases are Three here.
2) The program will compare each pair of the input (Student1, Student2) and the output will showcase the result of the comparison.
3) If the names are same the program will compare each pair of input (id1,id2); this time it will be the id of the students.

## Comparison Logic
As the Main Process discuss the comparisons Steps: Primary and Secondary
1) Primary Comparison based on the Alphabetical order, the compareTo method will compares String with the Current String Lexicographically.The Comparison based on the Unicode of the Each char and String.

2) Secondary Comparison based on the Numerical order, the compareTo method will compares integer with the Current integer Lexicographically. The Comparison based on the Unicode of the Each Integer.

4) Final Logic based on the Unicode:
Word1 < word2 = -1
Word1 > word2 = 1
Word1 = word = 0

5) If else statement:
This statement will compare the Unicode value given with zero and it will print the comparison result, followed by the Else if to check for whether the Unicode is positive or not, if yes then it will print the comparison result. Now the final else; it will execute another if else where the Ids of the students will be compared using same logic discussed above and the method follows until the comparison is done.

## Cammand to Run the JAR file
1) Create Jar file using this Cammand:
```jar cfe StudentComparison.jar Student Student.class```

2) To run the jar file using this command:
```java -jar StudentComparison.jar```


# Student Comparison Java Program


```java
import java.util.Scanner;

public class Student implements Comparable<Student>{
    private String name;
    private int id;

    // Getter Setter for name and id 
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    @Override
    public int compareTo(Student other) {
        int comparsionResult = this.name.compareTo(other.getName());
        if (comparsionResult < 0) {
            return -1;
        } else if(comparsionResult > 0) {
            return 1;
        } else {
            if(this.id > other.id) {
                return -1;
            } else {
                return 1;
            }
        }
    }

    public class Main {
    
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            
            Student biggestStudent;

            // Create Student objects for multiple cases
            Student student1 = new Student();
            Student student2 = new Student();
            Student student3 = new Student();
            Student student4 = new Student();

            System.out.println("Enter Student Details");
            System.out.print("Enter Student 1 Name: ");
            student1.setName(scanner.nextLine());
            System.out.print("Enter Student 1 ID: ");
            student1.setId(scanner.nextInt());
            scanner.nextLine(); 

            System.out.print("Enter Student 2 Name: "); 
            student2.setName(scanner.nextLine());
            System.out.print("Enter Student 2 ID: ");
            student2.setId(scanner.nextInt());
            scanner.nextLine(); 
            
            if(student1.compareTo(student2) > 0) {
                biggestStudent = student1;
            } else {
                biggestStudent = student2;
            }
            
            System.out.println("Biggest student is " + biggestStudent.getName() + " with id " + biggestStudent.getId());

            System.out.print("Enter Student 3 Name: ");
            student3.setName(scanner.nextLine());
            System.out.print("Enter Student 3 ID: ");
            student3.setId(scanner.nextInt());
            scanner.nextLine();
            
            if(biggestStudent.compareTo(student3) < 0) {
                biggestStudent = student3;
            }

            System.out.println("Biggest student is " + biggestStudent.getName() + " with id " + biggestStudent.getId());

            scanner.close();
        }
    }
}
```





